module EmailsHelper
end
